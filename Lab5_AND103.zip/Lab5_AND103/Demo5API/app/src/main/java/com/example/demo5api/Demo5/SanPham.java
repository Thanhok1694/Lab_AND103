package com.example.demo5api.Demo5;

public class SanPham {
    private String MaSP,TenSP,Mota;

    public SanPham(String maSP, String tenSP, String mota) {
        MaSP = maSP;
        TenSP = tenSP;
        Mota = mota;
    }

    public SanPham() {
    }

    public String getMaSP() {
        return MaSP;
    }

    public void setMaSP(String maSP) {
        MaSP = maSP;
    }

    public String getTenSP() {
        return TenSP;
    }

    public void setTenSP(String tenSP) {
        TenSP = tenSP;
    }

    public String getMota() {
        return Mota;
    }

    public void setMota(String mota) {
        Mota = mota;
    }
}
