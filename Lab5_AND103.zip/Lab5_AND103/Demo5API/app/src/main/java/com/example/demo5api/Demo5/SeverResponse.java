package com.example.demo5api.Demo5;

public class SeverResponse {
    private SanPham sanpham;
    private String message;

    public SanPham getSanpham() {
        return sanpham;
    }

    public String getMessage() {
        return message;
    }
}
