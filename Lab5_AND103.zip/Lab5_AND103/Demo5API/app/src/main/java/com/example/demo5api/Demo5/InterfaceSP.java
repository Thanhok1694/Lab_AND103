package com.example.demo5api.Demo5;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface InterfaceSP {
    @FormUrlEncoded
    @POST("insert2.php")
    Call<SeverResponse> insertSanPham(
      @Field("MaSP") String MaSP,
      @Field("TenSP") String TenSP,
      @Field("Mota") String Mota
    );
}
