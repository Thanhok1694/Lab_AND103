package com.example.demo5api.Demo5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo5api.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Demo5MainActivity extends AppCompatActivity {
EditText edt1,edt2,edt3;
TextView txtKQ;
Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo5_main);
        edt1=findViewById(R.id.Demo51edt1);
        edt2=findViewById(R.id.Demo51edt2);
        edt3=findViewById(R.id.Demo51edt3);
        txtKQ=findViewById(R.id.Demo51txtKQ);
        btn1=findViewById(R.id.Demo51btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertData(edt1,edt2,edt3,txtKQ);
            }
        });
    }
    private void insertData(EditText edt1, EditText edt2, EditText edt3, TextView txtKQ){
        //b1 tao doi tuong chua du lieu
        SanPham s=new SanPham(edt1.getText().toString(),
                edt2.getText().toString(),
                edt3.getText().toString());
        //b2 tao doi tuong retrofit
        Retrofit retro=new Retrofit.Builder()
                .baseUrl("http://192.168.1.121/000/Lab5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //b3 goi ham insert
       InterfaceSP insertSP
                =retro.create(InterfaceSP.class);
       //chuan bi ham
        Call<SeverResponse> call=insertSP.insertSanPham(s.getMaSP(),s.getTenSP(),s.getMota());
        //thuc thi ham
        call.enqueue(new Callback<SeverResponse>() {
            @Override
            public void onResponse(Call<SeverResponse> call, Response<SeverResponse> response) {
                SeverResponse res=response.body();
                txtKQ.setText(res.getMessage());
            }

            @Override
            public void onFailure(Call<SeverResponse> call, Throwable t) {
        txtKQ.setText(t.getMessage());
            }
        });

    }
}