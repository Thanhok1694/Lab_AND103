<?php
$res=array();
$s="localhost"; $u="root";$p="";$db="db1";
$con=new mysqli($s,$u,$p,$db);
$MaSP=$_POST['MaSP'];
$TenSP=$_POST['TenSP'];
$Mota=$_POST['Mota'];
$sql="INSERT into SanPham (MaSP,TenSP,Mota) VALUES ('$MaSP','$TenSP','$Mota')";
if($con->query($sql)===TRUE){
    $res['Success']=1;
    $res['message']="insert thanh cong";
    echo json_encode($res);
}else{
    $res['Success']=0;
    $res['message']="insert that bai";
    echo json_encode($res);
}
$con->close();
//http://localhost/000/Lab5/insert.php?MaSP=SP2&TenSP=San pham 2&Mota=Mo ta 3