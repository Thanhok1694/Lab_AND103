<?php
$s="localhost"; $u="root";$p="";$db="db1";
$con=new mysqli($s,$u,$p,$db);
$MaSP=$_GET['MaSP'];
$TenSP=$_GET['TenSP'];
$Mota=$_GET['Mota'];
$sql="INSERT into SanPham (MaSP,TenSP,Mota) VALUES ('$MaSP','$TenSP','$Mota')";
if($con->query($sql)===TRUE){
    echo "insert thanh cong";
}else{
    echo "Loi: ".$con->error;
}
$con->close();
//http://localhost/000/Lab5/insert.php?MaSP=SP2&TenSP=San pham 2&Mota=Mo ta 3