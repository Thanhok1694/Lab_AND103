
const express=require('express');
const router=express.Router();
const sinhvien=require('../models/sinhvienModels');

router.get('/', async (req,res)=>{ 
    try {
        const sinhviens =  await sinhvien.find();
        res.render('sinhviens',{sinhviens: sinhviens});
        console.log(sinhviens);
    } catch (err){
        console.error(err);
        res.status(500).json({error: 'Khong ket noi duoc voi server'});
    }
});
//POST: tao moi 1 sinh vien
//http://localhost:3000/sinhvien
router.post('/', async (req,res)=>{
    try{
        const {id,name}=req.body; 
        const sinhvien1=new sinhvien({id,name});
        await sinhvien1.save();
        res.status(201).json(sinhvien1);
        console.log(sinhvien1);
    } catch(err){
        console.error(err);
        res.status(500).json({error : "khong ket noi duoc voi server"});
    }
});
router.put('/:_id',async (req,res)=>{
    try {
        const { _id }=req.params;
        const {name,id}=req.body;
        const updatedSinhVien=await sinhvien.findByIdAndUpdate(_id,{id,name},{new: true});
        res.json(updatedSinhVien);
        console.log(updatedSinhVien);
    } catch (error) {
        console.error(error);
        res.status(500).json({error: "Khong ket noi duoc voi server"});
    }
});
module.exports=router;