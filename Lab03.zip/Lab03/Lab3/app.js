
const express=require('express');
const mongoose=require('mongoose');
const sinhVienRoute=require('./routes/sinhvienRoutes');
const bodyParser = require('body-parser');
const app=express();
mongoose.connect('mongodb+srv://thanh2:169@cluster0.lvh3arx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0/test',{
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(()=>{
    console.log("ket noi thanh cong voi mongodb");
}).catch((err)=>{
    console.error("Loi ket noi: ",err);
});
app.use(bodyParser.urlencoded({extended:false}));
app.use(express.json());
app.use('/sinhvien',sinhVienRoute);
app.use('/',sinhVienRoute);
app.set('view engine','ejs');
const PORT=process.env.PORT||3000;
app.listen(PORT,()=>{
    console.log("server dang chay o cong 3000");
});